// Nexus Looker — generated bundle, do not edit
// version 0.1.0
define(["jquery"], function ($) {
var NXLooker = (() => {
  var __defProp = Object.defineProperty;
  var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
  var __getOwnPropNames = Object.getOwnPropertyNames;
  var __hasOwnProp = Object.prototype.hasOwnProperty;
  var __export = (target, all) => {
    for (var name in all)
      __defProp(target, name, { get: all[name], enumerable: true });
  };
  var __copyProps = (to, from, except, desc) => {
    if (from && typeof from === "object" || typeof from === "function") {
      for (let key of __getOwnPropNames(from))
        if (!__hasOwnProp.call(to, key) && key !== except)
          __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
    }
    return to;
  };
  var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);

  // src/script.js
  var script_exports = {};
  __export(script_exports, {
    default: () => makeWidget
  });

  // src/fileUtils.js
  var EXT_TO_KIND = {
    pdf: "pdf",
    // svg НЕ предпросматриваем inline: <img src=blob:svg> исполнит встроенные
    // скрипты/обработчики (XSS внутри страницы amoCRM) → отдаём на «Скачать».
    jpg: "image",
    jpeg: "image",
    png: "image",
    gif: "image",
    webp: "image",
    txt: "text",
    csv: "text",
    json: "text",
    md: "text",
    log: "text",
    docx: "docx",
    xlsx: "xlsx",
    doc: "legacy",
    xls: "legacy",
    ppt: "legacy",
    pptx: "legacy",
    rtf: "legacy",
    odt: "legacy",
    ods: "legacy",
    odp: "legacy"
  };
  function extractExt(file) {
    const name = (file.name || "").toLowerCase();
    const fromName = name.match(/\.([a-z0-9]+)(?:$|\?)/);
    if (fromName) return fromName[1];
    const href = (file.href || "").toLowerCase().split("?")[0];
    const fromHref = href.match(/\.([a-z0-9]+)$/);
    return fromHref ? fromHref[1] : "";
  }
  function detectKind(file) {
    const ext = extractExt(file);
    return EXT_TO_KIND[ext] || null;
  }
  function canPreview(file) {
    return !!detectKind(file);
  }

  // src/inject.js
  var FEED_ROOT_SELECTORS = [
    ".notes-wrapper__notes.js-notes",
    // реальный (лента примечаний карточки)
    ".js-notes",
    ".notes-wrapper"
  ];
  var FILE_ROW_SELECTORS = [
    ".feed-note__joined-attach-item",
    // реальный
    ".feed-note__joined-attach__link"
    // fallback: сама ссылка, если структура иная
  ];
  var FILE_LINK_SELECTOR = 'a.feed-note__joined-attach__link, a[href*="/download/"], a[href*="drive-a.amocrm"], a[href*="/download/drive/"]';
  var INJECTED_ATTR = "data-nx-injected";
  var RETRY_MS = 800;
  var Injector = class {
    constructor({ $, onEyeClick }) {
      this.$ = $;
      this.onEyeClick = onEyeClick;
      this.observer = null;
      this._retryTimer = null;
      this._click = this._click.bind(this);
    }
    start() {
      this._teardownObserver();
      const roots = this._findRoots();
      if (!roots.length) {
        this._retryTimer = setTimeout(() => {
          this._retryTimer = null;
          this.start();
        }, RETRY_MS);
        return;
      }
      this.observer = new MutationObserver((mutations) => {
        mutations.forEach((m) => {
          m.addedNodes.forEach((n) => {
            if (n.nodeType === 1) this._injectInto(n);
          });
        });
      });
      roots.forEach((root) => {
        this.observer.observe(root, { childList: true, subtree: true });
        this._injectInto(root);
      });
      this.$(document).off("click.nxLooker").on("click.nxLooker", ".nx-eye", this._click);
    }
    stop() {
      this._teardownObserver();
      this.$(document).off("click.nxLooker");
      this.$(".nx-eye").remove();
      this.$(`[${INJECTED_ATTR}]`).removeAttr(INJECTED_ATTR);
    }
    // Снять наблюдатель и отложенный retry, не трогая уже вставленные кнопки.
    _teardownObserver() {
      if (this.observer) {
        this.observer.disconnect();
        this.observer = null;
      }
      if (this._retryTimer) {
        clearTimeout(this._retryTimer);
        this._retryTimer = null;
      }
    }
    _findRoots() {
      const found = [];
      for (const sel of FEED_ROOT_SELECTORS) {
        this.$(sel).each(function() {
          found.push(this);
        });
        if (found.length) break;
      }
      return found;
    }
    _injectInto(node) {
      FILE_ROW_SELECTORS.forEach((sel) => {
        const matches = node.matches && node.matches(sel) ? [node] : node.querySelectorAll ? node.querySelectorAll(sel) : [];
        Array.prototype.forEach.call(matches, (row) => this._injectRow(row));
      });
    }
    _injectRow(row) {
      const link = this._findLink(row);
      if (!link) return;
      const meta = { href: link.href, name: link.textContent.trim() || link.getAttribute("download") || "file" };
      if (!meta.href || !canPreview(meta)) return;
      const host = link.parentNode || row;
      const marked = link.getAttribute(INJECTED_ATTR);
      const existing = host.querySelector(":scope > .nx-eye");
      if (marked === meta.href && existing) return;
      if (existing) existing.remove();
      link.setAttribute(INJECTED_ATTR, meta.href);
      host.appendChild(this._makeButton(meta));
    }
    _findLink(row) {
      return row.matches && row.matches("a") ? row : row.querySelector(FILE_LINK_SELECTOR);
    }
    _makeButton(meta) {
      const btn = document.createElement("span");
      btn.className = "nx-eye";
      btn.setAttribute("data-href", meta.href);
      btn.setAttribute("data-name", meta.name);
      btn.setAttribute("title", "\u041F\u0440\u0435\u0434\u043F\u0440\u043E\u0441\u043C\u043E\u0442\u0440");
      btn.innerHTML = '<svg viewBox="0 0 24 24" width="14" height="14" aria-hidden="true"><path fill="currentColor" d="M12 5c-7 0-11 7-11 7s4 7 11 7 11-7 11-7-4-7-11-7zm0 11a4 4 0 110-8 4 4 0 010 8zm0-2a2 2 0 100-4 2 2 0 000 4z"/></svg>';
      return btn;
    }
    _click(e) {
      e.preventDefault();
      e.stopPropagation();
      const $btn = this.$(e.currentTarget);
      this.onEyeClick({
        href: $btn.data("href"),
        name: $btn.data("name")
      });
    }
  };

  // src/loader.js
  function keyedError(langKey, detail, langParams) {
    const e = new Error(detail || langKey);
    e.langKey = langKey;
    if (langParams) e.langParams = langParams;
    return e;
  }
  var Loader = class {
    constructor() {
      this._controllers = /* @__PURE__ */ new Set();
      this._urls = /* @__PURE__ */ new Set();
    }
    // Загрузить файл → { buf, bytes, contentType }. maxBytes проверяется ПОСЛЕ
    // загрузки по реальному размеру (content-length ненадёжен при chunked).
    async fetchBuffer(href, { maxBytes } = {}) {
      const ctrl = new AbortController();
      this._controllers.add(ctrl);
      try {
        let resp;
        try {
          resp = await fetch(href, { credentials: "same-origin", signal: ctrl.signal });
        } catch (e) {
          if (e && e.name === "AbortError") throw e;
          throw keyedError("fetch_failed", "network: " + (e && e.message));
        }
        if (!resp.ok) throw keyedError("fetch_failed", "HTTP " + resp.status);
        const buf = await resp.arrayBuffer();
        if (maxBytes && buf.byteLength > maxBytes) {
          throw keyedError("too_large", "bytes " + buf.byteLength, { limit: humanSize(maxBytes) });
        }
        return { buf, bytes: buf.byteLength, contentType: resp.headers.get("content-type") || "" };
      } finally {
        this._controllers.delete(ctrl);
      }
    }
    // POST на внешний сервис (конвертер). Отдельно от fetchBuffer: cross-origin,
    // без credentials. Тоже отменяется при dispose().
    async post(url, body, headers) {
      const ctrl = new AbortController();
      this._controllers.add(ctrl);
      try {
        return await fetch(url, { method: "POST", headers, body, signal: ctrl.signal });
      } finally {
        this._controllers.delete(ctrl);
      }
    }
    // Создать blob: URL под уже загруженный буфер; трекается для revoke в dispose().
    objectURL(buf, type) {
      const url = URL.createObjectURL(new Blob([buf], type ? { type } : void 0));
      this._urls.add(url);
      return url;
    }
    // Отменить все незавершённые загрузки и освободить objectURL'ы.
    dispose() {
      this._controllers.forEach((c) => {
        try {
          c.abort();
        } catch (e) {
        }
      });
      this._controllers.clear();
      this._urls.forEach((u) => {
        try {
          URL.revokeObjectURL(u);
        } catch (e) {
        }
      });
      this._urls.clear();
    }
  };
  function humanSize(bytes) {
    const mb = bytes / (1024 * 1024);
    return (Number.isInteger(mb) ? mb : mb.toFixed(0)) + " \u041C\u0411";
  }

  // src/renderers/pdf.js
  function render({ $, file, $body, loader }) {
    const ready = (file.href || "").startsWith("blob:") ? Promise.resolve(file.href) : loader.fetchBuffer(file.href).then(({ buf }) => loader.objectURL(buf, "application/pdf"));
    return ready.then((url) => new Promise((resolve) => {
      const $iframe = $('<iframe class="nx-render-pdf"/>').attr("src", url);
      $body.empty().append($iframe);
      $iframe.on("load", resolve);
      setTimeout(resolve, 4e3);
    }));
  }

  // src/renderers/image.js
  function render2({ $, file, $body, loader }) {
    return loader.fetchBuffer(file.href).then(({ buf, contentType }) => {
      const url = loader.objectURL(buf, contentType || "");
      return new Promise((resolve) => {
        const $img = $('<img class="nx-render-image"/>').attr("src", url).attr("alt", file.name);
        $body.empty().append($img);
        $img.on("load", resolve).on("error", () => resolve());
      });
    });
  }

  // src/renderers/text.js
  var MAX = 2 * 1024 * 1024;
  function render3({ $, file, $body, loader }) {
    return loader.fetchBuffer(file.href, { maxBytes: MAX }).then(({ buf }) => {
      const txt = new TextDecoder("utf-8").decode(buf);
      $body.empty().append($('<pre class="nx-render-text"/>').text(txt));
    });
  }

  // src/vendorLoader.js
  var SCRIPT_TIMEOUT_MS = 2e4;
  var _hideDepth = 0;
  var _savedDefine;
  function hideDefine() {
    if (_hideDepth === 0) {
      _savedDefine = window.define;
      if (_savedDefine) window.define = void 0;
    }
    _hideDepth++;
  }
  function restoreDefine() {
    if (_hideDepth > 0) _hideDepth--;
    if (_hideDepth === 0 && _savedDefine) {
      window.define = _savedDefine;
      _savedDefine = void 0;
    }
  }
  var _chain = Promise.resolve();
  function loadVendorScripts(srcs) {
    const run = () => _loadSequential(srcs);
    _chain = _chain.then(run, run);
    return _chain;
  }
  function _loadSequential(srcs) {
    return new Promise((resolve, reject) => {
      hideDefine();
      let i = 0, settled = false;
      const finish = (fn, arg) => {
        if (settled) return;
        settled = true;
        restoreDefine();
        fn(arg);
      };
      const next = () => {
        if (settled) return;
        if (i >= srcs.length) {
          finish(resolve);
          return;
        }
        const src = srcs[i++];
        const s = document.createElement("script");
        const timer = setTimeout(() => {
          s.onload = s.onerror = null;
          s.remove();
          finish(reject, new Error("vendor load timeout: " + src));
        }, SCRIPT_TIMEOUT_MS);
        s.onload = () => {
          if (settled) return;
          clearTimeout(timer);
          next();
        };
        s.onerror = () => {
          if (settled) return;
          clearTimeout(timer);
          s.remove();
          finish(reject, new Error("vendor load failed: " + src));
        };
        s.src = src;
        document.head.appendChild(s);
      };
      next();
    });
  }

  // src/renderers/docx.js
  var _libPromise = null;
  function ensureLib(params) {
    if (window.docx && window.docx.renderAsync) return Promise.resolve(window.docx);
    if (_libPromise) return _libPromise;
    const base = params && params.path ? params.path : "";
    _libPromise = loadVendorScripts([base + "/vendor/jszip.min.js", base + "/vendor/docx-preview.min.js"]).then(() => {
      if (window.docx && window.docx.renderAsync) return window.docx;
      throw new Error("docx-preview \u0437\u0430\u0433\u0440\u0443\u0436\u0435\u043D, \u043D\u043E window.docx.renderAsync \u043D\u0435\u0434\u043E\u0441\u0442\u0443\u043F\u0435\u043D");
    }).catch((e) => {
      _libPromise = null;
      throw e;
    });
    return _libPromise;
  }
  function render4({ file, $body, params, loader }) {
    return Promise.all([
      ensureLib(params),
      loader.fetchBuffer(file.href).then(({ buf }) => buf)
    ]).then(([docx, buf]) => {
      const container = document.createElement("div");
      container.className = "nx-render-docx";
      $body.empty().append(container);
      return docx.renderAsync(buf, container);
    });
  }

  // src/renderers/xlsx.js
  var MAX2 = 10 * 1024 * 1024;
  var MAX_ROWS = 2e3;
  var _libPromise2 = null;
  function ensureLib2(params) {
    if (window.XLSX && window.XLSX.read) return Promise.resolve(window.XLSX);
    if (_libPromise2) return _libPromise2;
    const base = params && params.path ? params.path : "";
    _libPromise2 = loadVendorScripts([base + "/vendor/xlsx.full.min.js"]).then(() => {
      if (window.XLSX && window.XLSX.read) return window.XLSX;
      throw new Error("SheetJS \u0437\u0430\u0433\u0440\u0443\u0436\u0435\u043D, \u043D\u043E window.XLSX.read \u043D\u0435\u0434\u043E\u0441\u0442\u0443\u043F\u0435\u043D");
    }).catch((e) => {
      _libPromise2 = null;
      throw e;
    });
    return _libPromise2;
  }
  function renderSheet($, XLSX, sheet) {
    const allRows = XLSX.utils.sheet_to_json(sheet, { header: 1, blankrows: false, defval: "" });
    const rows = allRows.slice(0, MAX_ROWS);
    const $wrap = $("<div/>");
    const $table = $("<table/>");
    rows.forEach((row) => {
      const $tr = $("<tr/>");
      (Array.isArray(row) ? row : [row]).forEach((cell) => {
        $tr.append($("<td/>").text(cell == null ? "" : String(cell)));
      });
      $table.append($tr);
    });
    $wrap.append($table);
    if (allRows.length > MAX_ROWS) {
      $wrap.append($('<div class="nx-xlsx-truncated"/>').text(
        "\u041F\u043E\u043A\u0430\u0437\u0430\u043D\u044B \u043F\u0435\u0440\u0432\u044B\u0435 " + MAX_ROWS + " \u0441\u0442\u0440\u043E\u043A \u0438\u0437 " + allRows.length + ". \u0421\u043A\u0430\u0447\u0430\u0439\u0442\u0435 \u0444\u0430\u0439\u043B \u0434\u043B\u044F \u043F\u043E\u043B\u043D\u043E\u0433\u043E \u043F\u0440\u043E\u0441\u043C\u043E\u0442\u0440\u0430."
      ));
    }
    return $wrap;
  }
  function render5({ $, file, $body, params, loader }) {
    return Promise.all([
      ensureLib2(params),
      loader.fetchBuffer(file.href, { maxBytes: MAX2 }).then(({ buf }) => buf)
    ]).then(([XLSX, buf]) => {
      const wb = XLSX.read(buf, { type: "array" });
      const $wrap = $('<div class="nx-render-xlsx"/>');
      const $tabs = $('<div class="nx-xlsx-tabs"/>');
      const $sheet = $('<div class="nx-xlsx-sheet"/>');
      const show = (name) => {
        $sheet.empty().append(renderSheet($, XLSX, wb.Sheets[name]));
      };
      wb.SheetNames.forEach((name, i) => {
        const $tab = $('<button class="nx-xlsx-tab"/>').text(name).on("click", () => {
          $tabs.find(".nx-xlsx-tab").removeClass("is-active");
          $tab.addClass("is-active");
          show(name);
        });
        if (i === 0) $tab.addClass("is-active");
        $tabs.append($tab);
      });
      show(wb.SheetNames[0]);
      $wrap.append($tabs).append($sheet);
      $body.empty().append($wrap);
    });
  }

  // src/renderers/legacy.js
  var DEFAULT_ENDPOINT = "https://nexus-oko.naithon.one/convert";
  var MAX3 = 50 * 1024 * 1024;
  function render6({ $, file, $body, settings, loader }) {
    const endpoint = settings && settings.converter_url || DEFAULT_ENDPOINT;
    const token = settings && settings.converter_token || "";
    return loader.fetchBuffer(file.href, { maxBytes: MAX3 }).then(({ buf }) => loader.post(endpoint, buf, {
      "Content-Type": "application/octet-stream",
      "X-Filename": encodeURIComponent(file.name),
      "X-Source-Token": token,
      "Accept": "application/pdf"
    })).then(async (r) => {
      if (!r.ok) throw keyedError("converter_failed", "HTTP " + r.status);
      const ct = r.headers.get("content-type") || "";
      if (!ct.includes("pdf")) {
        throw keyedError("converter_failed", "content-type " + ct);
      }
      const pdfBuf = await r.arrayBuffer();
      const url = loader.objectURL(pdfBuf, "application/pdf");
      return render({ $, file: { href: url, name: file.name + ".pdf" }, $body, loader });
    });
  }

  // src/modal.js
  var RENDERERS = { pdf: render, image: render2, text: render3, docx: render4, xlsx: render5, legacy: render6 };
  var Modal = class {
    constructor({ $, langs, params, getSettings }) {
      this.$ = $;
      this.langs = langs || {};
      this.params = params || {};
      this.getSettings = getSettings || (() => ({}));
      this.$root = null;
      this._loader = null;
    }
    open(file) {
      this.close();
      const $ = this.$;
      this.$root = $(
        '<div class="nx-modal-overlay"><div class="nx-modal"><div class="nx-modal__head"><span class="nx-modal__name"></span><a class="nx-modal__download" target="_blank" rel="noopener"></a><button class="nx-modal__close" aria-label="Close">&times;</button></div><div class="nx-modal__body"><div class="nx-modal__loading"></div></div></div></div>'
      );
      this.$root.find(".nx-modal__name").text(file.name);
      this.$root.find(".nx-modal__download").attr("href", file.href).text(this._t("modal.download"));
      this.$root.find(".nx-modal__loading").text(this._t("modal.loading"));
      this.$root.on("click", (e) => {
        if (e.target === this.$root[0]) this.close();
      });
      this.$root.find(".nx-modal__close").on("click", () => this.close());
      this._onKeydown = (e) => {
        if (e.key === "Escape") this.close();
      };
      $(document).on("keydown.nxLooker", this._onKeydown);
      $("body").append(this.$root);
      const $body = this.$root.find(".nx-modal__body");
      const kind = file.kind || detectKind(file);
      if (!kind) {
        this._showError($body, this._tErr("unsupported"));
        return;
      }
      const loader = this._loader = new Loader();
      const renderer = RENDERERS[kind] || RENDERERS.legacy;
      Promise.resolve().then(() => renderer({
        $,
        file,
        $body,
        params: this.params,
        settings: this.getSettings(),
        langs: this.langs,
        loader
      })).catch((err) => {
        if (err && err.name === "AbortError") return;
        if (this._loader !== loader) return;
        const key = err && err.langKey;
        const msg = key ? this._tErr(key, err.langParams) : this._tErr("fetch_failed");
        this._showError($body, msg);
      });
    }
    close() {
      if (this._loader) {
        this._loader.dispose();
        this._loader = null;
      }
      if (this.$root) {
        this.$root.remove();
        this.$root = null;
      }
      if (this._onKeydown) {
        this.$(document).off("keydown.nxLooker", this._onKeydown);
        this._onKeydown = null;
      }
    }
    _showError($body, msg) {
      $body.empty().append(this.$('<div class="nx-modal__error"/>').text(msg));
    }
    _t(key) {
      const parts = key.split(".");
      const roots = this.langs && this.langs.widget ? [this.langs.widget, this.langs] : [this.langs || {}];
      for (const root of roots) {
        let node = root;
        for (const p of parts) {
          if (node == null || typeof node !== "object") {
            node = void 0;
            break;
          }
          node = node[p];
        }
        if (typeof node === "string") return node;
      }
      return key;
    }
    // Локализованный текст ошибки с подстановкой {{param}}.
    _tErr(langKey, params) {
      let s = this._t("errors." + langKey);
      if (s === "errors." + langKey) s = langKey;
      if (params) for (const k of Object.keys(params)) s = s.replace("{{" + k + "}}", params[k]);
      return s;
    }
  };

  // src/script.js
  function makeWidget($) {
    return function CustomWidget() {
      const self = this;
      self._injector = null;
      self._modal = null;
      self._area = null;
      this.callbacks = {
        render() {
          return true;
        },
        init() {
          self._area = self.system().area;
          self._modal = new Modal({ $, langs: self.langs, params: self.params, getSettings: () => self.get_settings() });
          self._injector = new Injector({ $, onEyeClick: (file) => self._modal.open(file) });
          self._injector.start();
          return true;
        },
        bind_actions() {
          return true;
        },
        settings() {
          return true;
        },
        advancedSettings() {
          return true;
        },
        onSave() {
          return true;
        },
        destroy() {
          if (self._injector) self._injector.stop();
          if (self._modal) self._modal.close();
        }
      };
    };
  }
  return __toCommonJS(script_exports);
})();

var factory = (typeof NXLooker !== "undefined" && NXLooker.default) ? NXLooker.default : null;
return factory ? factory($) : null;
});